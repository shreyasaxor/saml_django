from django.urls import path
from django.contrib import admin
from demo.views import index, attrs, metadata

admin.autodiscover()

urlpatterns = [
    path('', index, name='index'),
    path('attrs/', attrs, name='attrs'),
    path('metadata/', metadata, name='metadata')
]
